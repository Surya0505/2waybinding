import { Component } from '@angular/core';

@Component({
  selector: 'my-component',
  templateUrl: `./app.employeecomponent.html`,
})

export class employee{

	empId:number=101;
	empName:string="Surya";
	dept:string="FS";
	salary:number=60000;

}

