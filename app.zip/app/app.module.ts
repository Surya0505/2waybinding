import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }      from '@angular/forms';

import { AppComponent }  from './app.component';
import { employee }  from './app.employeecomponent';

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent,employee ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
